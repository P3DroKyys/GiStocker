"""
Área administrativa (View_Admin), protegida por PIN (config.PIN_ADMIN).

Permite:
  * consultar todos os produtos e suas características em uma tabela filtrável;
  * sobrescrever manualmente ``estoque_atual`` e ``custo_medio`` de um produto
    (gera obrigatoriamente um log do tipo "Ajuste");
  * vincular/desvincular códigos de barras de um produto já cadastrado.
"""
from __future__ import annotations

import sqlite3
from utils.erros import mensagem_falha

import customtkinter as ctk

import config
from controllers.controllers import ErroNegocio
from utils.texto import formatar_moeda
from views.painel_produtos import PainelProdutos
from views.componentes import (
    COR_PERIGO, COR_TEXTO_ERRO, COR_TEXTO_SUAVE, ListaCodigos, confirmar, criar_tabela, erro,
    informar, limpar_tabela,
)

COLUNAS_BUSCA = [
    ("id", "ID", 50, "center", False),
    ("nome", "Produto", 220, "w", True),
    ("marca", "Marca", 120, "w", False),
    ("estoque", "Estoque", 70, "e", False),
]


class ViewAdmin(ctk.CTkFrame):
    def __init__(self, master, janela):
        super().__init__(master, fg_color="transparent")
        self.janela = janela
        self.controlador = janela.controlador_estoque
        self.desbloqueado = False
        self.produto_atual = None
        self._construir_bloqueio()
        self._construir_admin()

    # ------------------------------------------------------------------ #
    # Tela de bloqueio (PIN)
    # ------------------------------------------------------------------ #
    def _construir_bloqueio(self) -> None:
        self.quadro_bloqueio = ctk.CTkFrame(self, fg_color="transparent")
        centro = ctk.CTkFrame(self.quadro_bloqueio, corner_radius=12)
        centro.place(relx=0.5, rely=0.45, anchor="center")
        ctk.CTkLabel(centro, text="🔒", font=ctk.CTkFont(size=40)).pack(pady=(28, 4), padx=60)
        ctk.CTkLabel(centro, text="Área administrativa", font=ctk.CTkFont(size=20, weight="bold")
                     ).pack(padx=28)
        ctk.CTkLabel(centro, text="Informe o PIN para continuar", text_color=COR_TEXTO_SUAVE
                     ).pack(pady=(0, 12))
        self.entrada_pin = ctk.CTkEntry(centro, width=200, height=44, show="•", justify="center",
                                        font=ctk.CTkFont(size=22))
        self.entrada_pin.pack(padx=28)
        self.entrada_pin.bind("<Return>", self._desbloquear)
        self.rotulo_erro_pin = ctk.CTkLabel(centro, text="", text_color=COR_TEXTO_ERRO)
        self.rotulo_erro_pin.pack(pady=(6, 0))
        ctk.CTkButton(centro, text="Desbloquear", width=200, height=40, command=self._desbloquear
                      ).pack(padx=28, pady=(4, 28))

    def _desbloquear(self, _evento=None) -> None:
        if self.entrada_pin.get() != config.PIN_ADMIN:
            self.rotulo_erro_pin.configure(text="PIN incorreto.")
            self.entrada_pin.delete(0, "end")
            return
        self.desbloqueado = True
        self.entrada_pin.delete(0, "end")
        self.rotulo_erro_pin.configure(text="")
        self._mostrar_quadro_correto()

    def _bloquear(self) -> None:
        self.desbloqueado = False
        self._limpar_produto()
        self._mostrar_quadro_correto()

    def _mostrar_quadro_correto(self) -> None:
        self.quadro_bloqueio.pack_forget()
        self.quadro_admin.pack_forget()
        if self.desbloqueado:
            self.quadro_admin.pack(fill="both", expand=True)
            self._ao_trocar_aba()
        else:
            self.quadro_bloqueio.pack(fill="both", expand=True)
            self.entrada_pin.focus_set()

    # ------------------------------------------------------------------ #
    # Área administrativa
    # ------------------------------------------------------------------ #
    def _construir_admin(self) -> None:
        self.quadro_admin = ctk.CTkFrame(self, fg_color="transparent")
        self.quadro_admin.grid_columnconfigure(0, weight=1)
        self.quadro_admin.grid_rowconfigure(1, weight=1)

        cabecalho = ctk.CTkFrame(self.quadro_admin, fg_color="transparent")
        cabecalho.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        ctk.CTkLabel(cabecalho, text="Administração", font=ctk.CTkFont(size=24, weight="bold")
                     ).pack(side="left")
        ctk.CTkButton(cabecalho, text="Bloquear", width=110, fg_color=COR_PERIGO[0],
                      hover_color=COR_PERIGO[1], command=self._bloquear).pack(side="right")

        self.abas = ctk.CTkTabview(self.quadro_admin, command=self._ao_trocar_aba)
        self.abas.grid(row=1, column=0, sticky="nsew")
        catalogo = self.abas.add("Produtos cadastrados")
        ajustes = self.abas.add("Ajustes e códigos")
        self.painel_produtos = PainelProdutos(catalogo, self.controlador, self._abrir_produto_catalogo)
        self.painel_produtos.pack(fill="both", expand=True)
        ajustes.grid_columnconfigure(0, weight=2, uniform="col")
        ajustes.grid_columnconfigure(1, weight=3, uniform="col")
        ajustes.grid_rowconfigure(1, weight=1)

        # ---- Esquerda: localizar produto ----
        busca = ctk.CTkFrame(ajustes, corner_radius=14)
        busca.grid(row=1, column=0, sticky="nsew", padx=(0, 12))
        busca.grid_columnconfigure(0, weight=1)
        busca.grid_rowconfigure(2, weight=1)
        ctk.CTkLabel(busca, text="Localizar produto", anchor="w",
                     font=ctk.CTkFont(size=16, weight="bold")).grid(row=0, column=0, sticky="ew", padx=14, pady=(14, 4))
        linha = ctk.CTkFrame(busca, fg_color="transparent")
        linha.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 8))
        self.entrada_busca = ctk.CTkEntry(linha, height=38,
                                          placeholder_text="Código de barras, nome ou marca + Enter")
        self.entrada_busca.pack(side="left", fill="x", expand=True, padx=(0, 8))
        for tecla in ("<Return>", "<KP_Enter>"):
            self.entrada_busca.bind(tecla, self._buscar)
        ctk.CTkButton(linha, text="Buscar", width=90, height=38, command=self._buscar).pack(side="left")
        quadro_tabela, self.tabela_busca = criar_tabela(busca, COLUNAS_BUSCA, altura=10)
        quadro_tabela.grid(row=2, column=0, sticky="nsew", padx=14, pady=(0, 14))
        self.tabela_busca.bind("<<TreeviewSelect>>", self._ao_selecionar)

        # ---- Direita: ajuste + códigos ----
        direita = ctk.CTkFrame(ajustes, fg_color="transparent")
        direita.grid(row=1, column=1, sticky="nsew")
        direita.grid_columnconfigure(0, weight=1)
        direita.grid_rowconfigure(1, weight=1)

        ajuste = ctk.CTkFrame(direita, corner_radius=14)
        ajuste.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        ajuste.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(ajuste, text="Ajuste manual de estoque e custo", anchor="w",
                     font=ctk.CTkFont(size=16, weight="bold")
                     ).grid(row=0, column=0, columnspan=2, sticky="ew", padx=14, pady=(14, 2))
        self.rotulo_produto = ctk.CTkLabel(ajuste, text="Nenhum produto selecionado.", anchor="w",
                                           justify="left", wraplength=520, text_color=COR_TEXTO_SUAVE)
        self.rotulo_produto.grid(row=1, column=0, columnspan=2, sticky="ew", padx=14, pady=(0, 8))

        ctk.CTkLabel(ajuste, text="Novo estoque atual", anchor="w").grid(row=2, column=0, sticky="w", padx=14, pady=4)
        self.entrada_estoque = ctk.CTkEntry(ajuste, width=160, height=36)
        self.entrada_estoque.grid(row=2, column=1, sticky="w", pady=4)
        ctk.CTkLabel(ajuste, text="Novo custo médio (R$)", anchor="w").grid(row=3, column=0, sticky="w", padx=14, pady=4)
        self.entrada_custo = ctk.CTkEntry(ajuste, width=160, height=36)
        self.entrada_custo.grid(row=3, column=1, sticky="w", pady=4)
        ctk.CTkLabel(ajuste, text="Motivo", anchor="w").grid(row=4, column=0, sticky="w", padx=14, pady=4)
        self.entrada_motivo = ctk.CTkEntry(ajuste, height=36, placeholder_text="ex.: contagem de inventário")
        self.entrada_motivo.grid(row=4, column=1, sticky="ew", padx=(0, 14), pady=4)
        ctk.CTkButton(ajuste, text="Aplicar ajuste (gera log 'Ajuste')", height=40,
                      command=self._aplicar_ajuste
                      ).grid(row=5, column=0, columnspan=2, sticky="ew", padx=14, pady=(10, 14))

        codigos = ctk.CTkFrame(direita, corner_radius=14)
        codigos.grid(row=1, column=0, sticky="nsew")
        ctk.CTkLabel(codigos, text="Códigos de barras do produto", anchor="w",
                     font=ctk.CTkFont(size=16, weight="bold")).pack(fill="x", padx=14, pady=(14, 6))
        linha_codigo = ctk.CTkFrame(codigos, fg_color="transparent")
        linha_codigo.pack(fill="x", padx=14)
        self.entrada_codigo = ctk.CTkEntry(linha_codigo, height=36,
                                           placeholder_text="Novo código de barras + Enter")
        self.entrada_codigo.pack(side="left", fill="x", expand=True, padx=(0, 8))
        for tecla in ("<Return>", "<KP_Enter>"):
            self.entrada_codigo.bind(tecla, self._vincular_codigo)
        ctk.CTkButton(linha_codigo, text="Vincular", width=90, height=36,
                      command=self._vincular_codigo).pack(side="left")
        self.lista_codigos = ListaCodigos(codigos, ao_remover=self._desvincular_codigo, altura=120)
        self.lista_codigos.pack(fill="both", expand=True, padx=14, pady=(8, 14))

    # ------------------------------------------------------------------ #
    # Protocolo da janela principal
    # ------------------------------------------------------------------ #
    def ao_mostrar(self, **_dados) -> None:
        self._mostrar_quadro_correto()

    def _ao_trocar_aba(self) -> None:
        if not self.desbloqueado:
            return
        if self.abas.get() == "Produtos cadastrados":
            self.painel_produtos.atualizar()
            self.painel_produtos.entrada_busca.focus_set()
        else:
            self.entrada_busca.focus_set()

    def _abrir_produto_catalogo(self, produto_id: int) -> None:
        if not self.desbloqueado:
            return
        self._carregar_produto(produto_id)
        self.abas.set("Ajustes e códigos")
        self.entrada_estoque.focus_set()

    # ------------------------------------------------------------------ #
    # Localizar / selecionar produto
    # ------------------------------------------------------------------ #
    def _buscar(self, _evento=None) -> None:
        termo = self.entrada_busca.get().strip()
        produto = self.controlador.resolver_codigo_barras(termo)
        produtos = [produto] if produto else self.controlador.buscar_produtos(termo)
        limpar_tabela(self.tabela_busca)
        for item in produtos:
            self.tabela_busca.insert("", "end", iid=str(item.id),
                                     values=(item.id, item.nome, item.marca, item.estoque_atual))
        if len(produtos) == 1:
            self.tabela_busca.selection_set(str(produtos[0].id))

    def _ao_selecionar(self, _evento=None) -> None:
        selecao = self.tabela_busca.selection()
        if selecao:
            self._carregar_produto(int(selecao[0]))

    def _carregar_produto(self, produto_id: int) -> None:
        try:
            produto = self.controlador.obter_produto(produto_id)
        except (ErroNegocio, sqlite3.Error, OSError) as falha:
            erro("Produto", mensagem_falha(falha))
            return
        self.produto_atual = produto
        self.rotulo_produto.configure(
            text=f"#{produto.id}  {produto.nome}  ({produto.marca} • {produto.categoria})\n"
                 f"Estoque atual: {produto.estoque_atual} un.   Custo médio: {formatar_moeda(produto.custo_medio)}   "
                 f"Preço base: {formatar_moeda(produto.preco_venda_base)}")
        self.entrada_estoque.delete(0, "end")
        self.entrada_estoque.insert(0, str(produto.estoque_atual))
        self.entrada_custo.delete(0, "end")
        self.entrada_custo.insert(0, str(produto.custo_medio).replace(".", ","))
        self.entrada_motivo.delete(0, "end")
        self.lista_codigos.definir(produto.codigos)

    def _limpar_produto(self) -> None:
        self.produto_atual = None
        self.rotulo_produto.configure(text="Nenhum produto selecionado.")
        for entrada in (self.entrada_estoque, self.entrada_custo, self.entrada_motivo,
                        self.entrada_codigo, self.entrada_busca):
            entrada.delete(0, "end")
        self.lista_codigos.limpar()
        limpar_tabela(self.tabela_busca)

    # ------------------------------------------------------------------ #
    # Ajuste manual
    # ------------------------------------------------------------------ #
    def _aplicar_ajuste(self) -> None:
        if self.produto_atual is None:
            erro("Ajuste", "Selecione um produto primeiro.")
            return
        if not confirmar("Confirmar ajuste",
                         f"Sobrescrever estoque/custo de '{self.produto_atual.nome}'?\n"
                         "Um log do tipo 'Ajuste' será gerado."):
            return
        try:
            estoque = self.entrada_estoque.get()
            custo = self.entrada_custo.get()
            # Campos inalterados não devem sobrescrever valores nem arredondar custos.
            if estoque == str(self.produto_atual.estoque_atual):
                estoque = None
            if custo == str(self.produto_atual.custo_medio).replace(".", ","):
                custo = None
            resultado = self.controlador.ajustar_produto(
                self.produto_atual.id, estoque, custo, self.entrada_motivo.get(),
                estoque_esperado=self.produto_atual.estoque_atual,
                custo_esperado=self.produto_atual.custo_medio)
        except (ErroNegocio, sqlite3.Error, OSError) as falha:
            erro("Ajuste", mensagem_falha(falha))
            return
        informar("Ajuste aplicado",
                 f"Estoque: {resultado.estoque_anterior} → {resultado.estoque_novo} un.\n"
                 f"Custo médio: {formatar_moeda(resultado.custo_anterior)} → {formatar_moeda(resultado.custo_novo)}")
        self._carregar_produto(self.produto_atual.id)
        self._buscar()

    # ------------------------------------------------------------------ #
    # Códigos de barras
    # ------------------------------------------------------------------ #
    def _vincular_codigo(self, _evento=None) -> None:
        if self.produto_atual is None:
            erro("Códigos", "Selecione um produto primeiro.")
            return
        try:
            codigo = self.controlador.validar_codigo_barras(self.entrada_codigo.get())
            self.controlador.vincular_codigo_barras(codigo, self.produto_atual.id)
        except (ErroNegocio, sqlite3.Error, OSError) as falha:
            erro("Códigos", mensagem_falha(falha))
            return
        self.lista_codigos.adicionar(codigo)
        self.entrada_codigo.delete(0, "end")
        self.entrada_codigo.focus_set()

    def _desvincular_codigo(self, codigo: str) -> bool:
        """Callback da ListaCodigos: remove do banco antes de tirar da lista."""
        if not confirmar("Desvincular código", f"Remover o código {codigo} deste produto?"):
            return False
        try:
            if self.produto_atual is None:
                raise ErroNegocio("Selecione novamente o produto antes de remover o código.")
            self.controlador.desvincular_codigo_barras(codigo, produto_id_esperado=self.produto_atual.id)
        except (ErroNegocio, sqlite3.Error, OSError) as falha:
            erro("Códigos", mensagem_falha(falha))
            return False
        return True
