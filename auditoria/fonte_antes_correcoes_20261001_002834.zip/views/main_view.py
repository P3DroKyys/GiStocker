"""
Janela principal (JanelaPrincipal): barra lateral de navegação + área de conteúdo.

Cada tela é um CTkFrame criado sob demanda e trocado na área central.
Protocolo opcional que as telas podem implementar:
  * ao_mostrar(**dados)  -> chamado sempre que a tela é exibida
                            (ex.: refocar o leitor, atualizar o dashboard);
  * ao_mudar_tema()      -> chamado após alternar claro/escuro
                            (ex.: redesenhar gráficos e cores de tabela).
Para navegar a partir de qualquer tela: ``self.janela.mostrar_view("cadastro", codigo="789...")``.
"""
from __future__ import annotations

from typing import Callable
import sys

import customtkinter as ctk
from PIL import Image

import config
from views.componentes import COR_TEXTO_SUAVE, aplicar_estilo_treeview
from views.view_admin import ViewAdmin
from views.view_cadastro import ViewCadastro
from views.view_dashboard import ViewDashboard
from views.view_operacao import ViewOperacao
from views.view_relatorios import ViewRelatorios

# (chave, rótulo do menu, atalho, classe)
TELAS = [
    ("operacao",   "Operação",   "F1", ViewOperacao),
    ("cadastro",   "Cadastro",   "F2", ViewCadastro),
    ("dashboard",  "Dashboard",  "F3", ViewDashboard),
    ("relatorios", "Relatórios", "F4", ViewRelatorios),
    ("admin",      "Admin",      "F5", ViewAdmin),
]


class JanelaPrincipal(ctk.CTk):
    def __init__(self, controlador_estoque, controlador_relatorios,
                 ao_fechar: Callable[[], None] | None = None):
        super().__init__()
        self.controlador_estoque = controlador_estoque
        self.controlador_relatorios = controlador_relatorios
        self._ao_fechar = ao_fechar

        self.title(config.NOME_APP)
        if sys.platform == "win32":
            self.iconbitmap(default=str(config.CAMINHO_ICONE))
        self.geometry(f"{config.LARGURA_JANELA}x{config.ALTURA_JANELA}")
        self.minsize(config.LARGURA_MINIMA, config.ALTURA_MINIMA)
        self.protocol("WM_DELETE_WINDOW", self._fechar)
        aplicar_estilo_treeview()

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.views: dict[str, ctk.CTkFrame] = {}
        self.view_atual: ctk.CTkFrame | None = None
        self.botoes_navegacao: dict[str, ctk.CTkButton] = {}

        self._construir_barra_lateral()
        self.container = ctk.CTkFrame(self, fg_color="transparent")
        self.container.grid(row=0, column=1, sticky="nsew", padx=24, pady=24)
        self.container.grid_rowconfigure(0, weight=1)
        self.container.grid_columnconfigure(0, weight=1)

        for chave, _, atalho, _ in TELAS:
            self.bind(f"<{atalho}>", lambda _e, c=chave: self.mostrar_view(c))

        self.mostrar_view("operacao")

    # ------------------------------------------------------------------ #
    # Barra lateral
    # ------------------------------------------------------------------ #
    def _construir_barra_lateral(self) -> None:
        barra = ctk.CTkFrame(self, width=216, corner_radius=0,
                            fg_color=("#E9EDF4", "#191E27"))
        barra.grid(row=0, column=0, sticky="nsw")
        barra.grid_propagate(False)
        barra.grid_rowconfigure(10, weight=1)     # empurra o rodapé para baixo

        # A imagem original tem transparência e é compartilhada pelos dois temas.
        with Image.open(config.CAMINHO_LOGO) as imagem:
            original = imagem.copy()
        largura_logo = 184
        altura_logo = round(largura_logo * original.height / original.width)
        self.logo = ctk.CTkImage(light_image=original, dark_image=original,
                                 size=(largura_logo, altura_logo))
        # CTkLabel adiciona padding interno quando há corner_radius. A logo
        # ocupa 184 + 2*16 = 216 px; não pode herdar esse padding do tema.
        ctk.CTkLabel(barra, text="", image=self.logo, corner_radius=0,
                     width=largura_logo, height=altura_logo, padx=0, pady=0
                     ).grid(row=0, column=0, padx=16, pady=(24, 18))
        ctk.CTkLabel(barra, text="NAVEGAÇÃO", text_color=COR_TEXTO_SUAVE,
                     font=ctk.CTkFont(size=10, weight="bold")
                     ).grid(row=1, column=0, padx=22, pady=(8, 10), sticky="w")

        for indice, (chave, rotulo, atalho, _) in enumerate(TELAS, start=2):
            botao = ctk.CTkButton(
                barra, text=f"{rotulo}   ·   {atalho}", anchor="w", height=44, corner_radius=10,
                fg_color="transparent", hover_color=("#DDE5F0", "#293342"),
                text_color=("#475467", "#AFBBCD"), font=ctk.CTkFont(size=14),
                command=lambda c=chave: self.mostrar_view(c),
            )
            botao.grid(row=indice, column=0, padx=12, pady=3, sticky="ew")
            self.botoes_navegacao[chave] = botao
        barra.grid_columnconfigure(0, weight=1)

        # Rodapé: alternância de tema e versão
        self.var_tema = ctk.StringVar(value=ctk.get_appearance_mode().lower())
        ctk.CTkSwitch(barra, text="Modo escuro", variable=self.var_tema,
                      onvalue="dark", offvalue="light", command=self.alternar_tema
                      ).grid(row=11, column=0, padx=20, pady=(0, 8), sticky="w")
        ctk.CTkLabel(barra, text=f"GiStocker  /  v{config.VERSAO_APP}",
                     text_color=COR_TEXTO_SUAVE, font=ctk.CTkFont(size=11)
                     ).grid(row=12, column=0, padx=20, pady=(0, 16), sticky="w")

    def _destacar_botao(self, chave_ativa: str) -> None:
        for chave, botao in self.botoes_navegacao.items():
            ativo = chave == chave_ativa
            botao.configure(fg_color=("#D3E6F8", "#233C56") if ativo else "transparent",
                            text_color=("#075B9F", "#99D3FF") if ativo else ("#475467", "#AFBBCD"),
                            font=ctk.CTkFont(size=14, weight="bold" if ativo else "normal"))

    # ------------------------------------------------------------------ #
    # Navegação
    # ------------------------------------------------------------------ #
    def mostrar_view(self, chave: str, **dados) -> None:
        """Exibe a tela ``chave``; ``dados`` são repassados a ``ao_mostrar``."""
        if chave not in self.views:
            classe = next(cls for c, _, _, cls in TELAS if c == chave)
            self.views[chave] = classe(self.container, self)
        if self.view_atual is not None:
            self.view_atual.grid_forget()
        view = self.views[chave]
        view.grid(row=0, column=0, sticky="nsew")
        self.view_atual = view
        self._destacar_botao(chave)
        if hasattr(view, "ao_mostrar"):
            view.ao_mostrar(**dados)

    # ------------------------------------------------------------------ #
    # Tema
    # ------------------------------------------------------------------ #
    def alternar_tema(self) -> None:
        ctk.set_appearance_mode(self.var_tema.get())
        aplicar_estilo_treeview()
        # Pequeno atraso para o customtkinter terminar de repintar os widgets.
        self.after(80, self._notificar_mudanca_tema)

    def _notificar_mudanca_tema(self) -> None:
        for view in self.views.values():
            if hasattr(view, "ao_mudar_tema"):
                view.ao_mudar_tema()

    # ------------------------------------------------------------------ #
    def _fechar(self) -> None:
        if self._ao_fechar is not None:
            self._ao_fechar()
        self.destroy()
