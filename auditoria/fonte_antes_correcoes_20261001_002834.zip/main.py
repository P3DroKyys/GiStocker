"""
Ponto de entrada da aplicação.

Monta as camadas na ordem MVC:
  Model (BancoDados) -> Controllers -> View (JanelaPrincipal) -> mainloop.

Execute a partir da pasta do projeto:  python main.py
"""
import os
import sys
import traceback
from datetime import datetime

import config  # importa só sys/pathlib: seguro carregar antes de tudo

# --------------------------------------------------------------------------- #
# Quando empacotado como .exe sem console (PyInstaller --windowed),
# sys.stdout e sys.stderr são None. Qualquer biblioteca que escreva neles
# (o customtkinter faz isso ao avisar sobre fontes) derrubaria o programa na
# importação. Por isso, ANTES de importar as bibliotecas gráficas, redirecionamos:
#   stdout -> descartado; stderr -> avisos.log ao lado do executável.
# --------------------------------------------------------------------------- #
if getattr(sys, "frozen", False):
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")
    if sys.stderr is None:
        try:
            sys.stderr = open(config.DIRETORIO_BASE / "avisos.log", "a", encoding="utf-8", buffering=1)
        except OSError:
            sys.stderr = open(os.devnull, "w", encoding="utf-8")

import customtkinter as ctk  # noqa: E402 - precisa vir após o redirecionamento acima

from controllers.controllers import ControladorEstoque, ControladorRelatorios  # noqa: E402
from models.models import BancoDados  # noqa: E402
from views.main_view import JanelaPrincipal  # noqa: E402


def main() -> None:
    if sys.platform == "win32":
        # Identidade própria na barra de tarefas, inclusive rodando pelo Python.
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("GiStocker.GestorEstoque")
    ctk.set_appearance_mode(config.APARENCIA_PADRAO)
    ctk.set_default_color_theme(config.TEMA_COR)

    banco = BancoDados(config.CAMINHO_BANCO)
    controlador_estoque = ControladorEstoque(banco)
    controlador_relatorios = ControladorRelatorios(banco)

    janela = JanelaPrincipal(controlador_estoque, controlador_relatorios, ao_fechar=banco.fechar)
    janela.mainloop()


def _registrar_falha(erro: BaseException) -> None:
    """Grava o erro em erros.log ao lado do programa e avisa o usuário.
    Necessário porque o .exe roda sem console e, sem isso, uma falha na
    inicialização passaria despercebida."""
    caminho_log = config.DIRETORIO_BASE / "erros.log"
    try:
        with open(caminho_log, "a", encoding="utf-8") as arquivo:
            arquivo.write(f"\n===== {datetime.now():%d/%m/%Y %H:%M:%S} =====\n")
            arquivo.write("".join(traceback.format_exception(erro)))
    except OSError:
        pass
    try:
        from tkinter import messagebox
        messagebox.showerror("Erro ao iniciar",
                             f"O programa encontrou um erro:\n\n{erro}\n\nDetalhes em:\n{caminho_log}")
    except Exception:  # noqa: BLE001 - último recurso, nada mais a fazer
        pass


if __name__ == "__main__":
    try:
        main()
    except Exception as falha:  # noqa: BLE001
        _registrar_falha(falha)
        raise
