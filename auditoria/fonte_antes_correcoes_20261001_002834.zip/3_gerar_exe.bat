@echo off
REM ==========================================================================
REM  Gera o executavel em dist\GestorEstoque\GestorEstoque.exe
REM  Rode sempre que quiser distribuir uma nova versao do programa.
REM ==========================================================================
cd /d "%~dp0"
setlocal
if not exist ".venv\Scripts\python.exe" (
    echo Ambiente nao encontrado. Rode primeiro o 1_preparar_ambiente.bat
    pause
    exit /b 1
)

REM Descobre onde o customtkinter esta instalado: seus arquivos de tema e fonte
REM precisam ser copiados para dentro do pacote, senao o .exe abre sem estilo.
REM (usebackq + crase permite usar aspas no codigo Python sem conflito)
set "CTK="
for /f "usebackq delims=" %%i in (`.venv\Scripts\python.exe -c "import customtkinter,os;print(os.path.dirname(customtkinter.__file__))"`) do set "CTK=%%i"
if "%CTK%"=="" (
    echo ERRO: customtkinter nao encontrado. Rode o 1_preparar_ambiente.bat novamente.
    pause
    exit /b 1
)

echo.
echo Gerando o executavel (leva cerca de 1 a 2 minutos) ...
echo.
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed ^
    --name GestorEstoque ^
    --icon "%~dp0assets\icone_gistocker.ico" ^
    --add-data "%CTK%;customtkinter" ^
    --add-data "%~dp0assets;assets" ^
    --distpath "dist" --workpath "build" --specpath "build" ^
    main.py
if errorlevel 1 (
    echo.
    echo ERRO ao gerar o executavel. Veja as mensagens acima.
    pause
    exit /b 1
)

echo.
echo Pronto! O programa esta em:  dist\GestorEstoque\GestorEstoque.exe
echo Para distribuir, compacte a pasta dist\GestorEstoque inteira.
echo.
pause
