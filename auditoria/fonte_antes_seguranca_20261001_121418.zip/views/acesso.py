"""Campo de senha reutilizável e tela de desbloqueio da aplicação."""
import sqlite3

import customtkinter as ctk
from PIL import Image

import config
from models.preferencias import ErroPreferencias
from views.componentes import COR_TEXTO_ERRO, COR_TEXTO_SUAVE


class CampoSenha(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.grid_columnconfigure(0, weight=1)
        self.entrada = ctk.CTkEntry(self, height=42, show="•")
        self.entrada.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        self.botao = ctk.CTkButton(
            self, text="Mostrar", width=76, height=42, fg_color="transparent",
            border_width=1, text_color=("#475467", "#AFBBCD"),
            hover_color=("#DDE5F0", "#293342"), command=self.alternar_visibilidade)
        self.botao.grid(row=0, column=1)

    def get(self):
        return self.entrada.get()

    def alternar_visibilidade(self):
        visivel = self.entrada.cget("show") == ""
        self.entrada.configure(show="•" if visivel else "")
        self.botao.configure(text="Mostrar" if visivel else "Ocultar")
        self.entrada.focus_set()

    def ocultar(self):
        self.entrada.configure(show="•")
        self.botao.configure(text="Mostrar")

    def limpar(self):
        self.entrada.delete(0, "end")
        self.ocultar()


class TelaAcesso(ctk.CTkFrame):
    def __init__(self, master, preferencias, ao_desbloquear):
        super().__init__(master, fg_color="transparent")
        self.preferencias = preferencias
        self.ao_desbloquear = ao_desbloquear
        self._ocupado = False
        self._espera = None
        cartao = ctk.CTkFrame(self, width=440, corner_radius=20)
        cartao.place(relx=0.5, rely=0.48, anchor="center")
        with Image.open(config.CAMINHO_LOGO) as arquivo:
            imagem = arquivo.copy()
        self.logo = ctk.CTkImage(light_image=imagem, dark_image=imagem,
                                size=(258, round(258 * imagem.height / imagem.width)))
        ctk.CTkLabel(cartao, text="", image=self.logo, corner_radius=0, padx=0
                     ).pack(padx=76, pady=(30, 22))
        ctk.CTkLabel(cartao, text="Bem-vindo de volta", font=ctk.CTkFont(size=24, weight="bold")
                     ).pack(padx=30)
        ctk.CTkLabel(cartao, text="Digite sua senha para acessar o GiStocker.",
                     text_color=COR_TEXTO_SUAVE).pack(padx=30, pady=(4, 24))
        ctk.CTkLabel(cartao, text="Senha de acesso", anchor="w").pack(fill="x", padx=30)
        self.campo_senha = CampoSenha(cartao)
        self.campo_senha.pack(fill="x", padx=30, pady=(6, 0))
        for tecla in ("<Return>", "<KP_Enter>"):
            self.campo_senha.entrada.bind(tecla, self._entrar)
        self.mensagem = ctk.CTkLabel(cartao, text="", wraplength=350,
                                     text_color=COR_TEXTO_ERRO)
        self.mensagem.pack(fill="x", padx=30, pady=(8, 4))
        self.botao_entrar = ctk.CTkButton(cartao, text="Desbloquear", height=44, command=self._entrar)
        self.botao_entrar.pack(fill="x", padx=30, pady=(0, 30))

    def _entrar(self, _evento=None):
        if self._ocupado:
            return
        self._ocupado = True
        self.botao_entrar.configure(state="disabled")
        self.campo_senha.ocultar()
        try:
            aceita = self.preferencias.verificar_senha(self.campo_senha.get())
        except (sqlite3.Error, OSError, ErroPreferencias):
            self.mensagem.configure(text="Não foi possível verificar o acesso. Confira as permissões "
                                        "e o arquivo dados/configuracoes.db.")
            self._reativar()
            return
        self.campo_senha.limpar()
        if not aceita:
            self.mensagem.configure(text="Senha incorreta. Tente novamente.")
            self._espera = self.after(1000, self._reativar)
            return
        self.mensagem.configure(text="")
        self.ao_desbloquear()

    def _reativar(self):
        self._espera = None
        self._ocupado = False
        self.botao_entrar.configure(state="normal")
        self.campo_senha.entrada.focus_set()

    def destroy(self):
        if self._espera is not None:
            self.after_cancel(self._espera)
        self.campo_senha.limpar()
        super().destroy()
