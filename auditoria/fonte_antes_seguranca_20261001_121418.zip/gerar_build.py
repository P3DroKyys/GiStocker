"""Empacota em um destino exclusivo; nunca limpa uma distribuição anterior."""
from datetime import datetime
from pathlib import Path
import subprocess
import sys
from uuid import uuid4


def gerar_build(projeto=None, executar=subprocess.run):
    import customtkinter
    projeto = Path(projeto or Path(__file__).resolve().parent).resolve()
    dist = projeto / 'dist'
    dist.mkdir(exist_ok=True)
    # Diretório de distribuição, não temporário: herda as permissões de dist.
    # No Python 3.13+ / Windows, mkdtemp cria ACL privada ao usuário compilador,
    # que pode ser uma conta de automação diferente da conta que abrirá a build.
    while True:
        destino = dist / f'GiStocker_{datetime.now():%Y%m%d_%H%M%S}_{uuid4().hex[:12]}'
        try:
            destino.mkdir()
        except FileExistsError:
            continue
        break
    trabalho = projeto / 'build' / destino.name
    trabalho.mkdir(parents=True)
    comando = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--windowed',
               '--name', 'GestorEstoque', '--icon', str(projeto / 'assets' / 'icone_gistocker.ico'),
               '--add-data', f'{Path(customtkinter.__file__).parent};customtkinter',
               '--add-data', f'{projeto / "assets"};assets',
               '--distpath', str(destino), '--workpath', str(trabalho),
               '--specpath', str(trabalho), str(projeto / 'main.py')]
    executar(comando, cwd=projeto, check=True)
    exe = destino / 'GestorEstoque' / 'GestorEstoque.exe'
    if not exe.is_file():
        raise RuntimeError('A geração terminou sem produzir o executável esperado.')
    return exe


if __name__ == '__main__':
    try:
        exe = gerar_build()
    except Exception as falha:
        print(f'ERRO ao gerar: {falha}', file=sys.stderr)
        sys.exit(1)
    print(f'\nPronto! Executável: {exe}\nPara distribuir, copie a pasta inteira: {exe.parent}')
    print('Versões anteriores e seus dados foram preservados.')
