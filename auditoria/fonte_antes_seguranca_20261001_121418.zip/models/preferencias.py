"""Preferências locais e senha de acesso, independentes dos dados de estoque.

Cada operação usa uma conexão curta. Trocas de senha são transacionais e
conferem a senha atual no banco, inclusive com duas instâncias abertas.
"""
from contextlib import closing
import hashlib
import hmac
from pathlib import Path
import secrets
import sqlite3

import config


ITERACOES = 600_000


class ErroPreferencias(RuntimeError):
    """Arquivo de configurações incompleto ou incompatível; nunca libera acesso."""


def _hash_senha(senha: str) -> str:
    sal = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), sal, ITERACOES)
    return f"pbkdf2_sha256${ITERACOES}${sal.hex()}${digest.hex()}"


def _confere_senha(senha: str, registro: str) -> bool:
    try:
        algoritmo, ciclos, sal, digest = registro.split("$")
        ciclos = int(ciclos)
        sal, digest = bytes.fromhex(sal), bytes.fromhex(digest)
        if algoritmo != "pbkdf2_sha256" or ciclos != ITERACOES or len(sal) != 16 or len(digest) != 32:
            raise ValueError
    except (ValueError, TypeError, AttributeError) as falha:
        raise ErroPreferencias("A configuração de acesso está inválida. Restaure o arquivo de configurações.") from falha
    if not isinstance(senha, str) or not senha or len(senha) > 256:
        return False
    calculado = hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), sal, ciclos)
    return hmac.compare_digest(calculado, digest)


class Preferencias:
    def __init__(self, caminho: str | Path, senha_inicial: str = config.SENHA_INICIAL):
        self.caminho = Path(caminho).resolve()
        arquivo_existente = self.caminho.exists()
        self.caminho.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._conectar(criar=True)) as conexao, conexao:
            conexao.execute("BEGIN IMMEDIATE")
            existente = conexao.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='Preferencias'"
            ).fetchone()
            if not existente:
                if arquivo_existente:
                    raise ErroPreferencias("O arquivo de configurações está incompleto. Restaure-o antes de acessar.")
                conexao.execute("""CREATE TABLE Preferencias (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    senha_hash TEXT NOT NULL,
                    tema TEXT NOT NULL CHECK (tema IN ('light', 'dark'))
                )""")
                tema = "light" if config.APARENCIA_PADRAO == "light" else "dark"
                conexao.execute("INSERT INTO Preferencias VALUES (1, ?, ?)", (_hash_senha(senha_inicial), tema))
            registro = self._ler(conexao)
            _confere_senha("", registro[0])  # valida formato sem alterar a senha existente

    def _conectar(self, criar=False):
        # mode=rw evita recriar silenciosamente um arquivo perdido durante a sessão.
        alvo = str(self.caminho) if criar else self.caminho.as_uri() + "?mode=rw"
        conexao = sqlite3.connect(alvo, uri=not criar, timeout=5)
        try:
            conexao.execute("PRAGMA synchronous=FULL")
        except sqlite3.Error:
            conexao.close()
            raise
        return conexao

    @staticmethod
    def _ler(conexao):
        registro = conexao.execute("SELECT senha_hash, tema FROM Preferencias WHERE id=1").fetchone()
        if registro is None or registro[1] not in ("light", "dark"):
            raise ErroPreferencias("As configurações estão incompletas. Restaure o arquivo de configurações.")
        return registro

    def verificar_senha(self, senha: str) -> bool:
        with closing(self._conectar()) as conexao:
            return _confere_senha(senha, self._ler(conexao)[0])

    def alterar_senha(self, antiga: str, nova: str, confirmacao: str) -> None:
        with closing(self._conectar()) as conexao, conexao:
            conexao.execute("BEGIN IMMEDIATE")
            if not _confere_senha(antiga, self._ler(conexao)[0]):
                raise ValueError("A senha atual está incorreta.")
            if not isinstance(nova, str) or not nova.strip() or not 4 <= len(nova) <= 256:
                raise ValueError("A nova senha deve ter entre 4 e 256 caracteres.")
            if nova != confirmacao:
                raise ValueError("A confirmação não corresponde à nova senha.")
            conexao.execute("UPDATE Preferencias SET senha_hash=? WHERE id=1", (_hash_senha(nova),))

    def obter_tema(self) -> str:
        with closing(self._conectar()) as conexao:
            return self._ler(conexao)[1]

    def definir_tema(self, tema: str) -> None:
        if tema not in ("light", "dark"):
            raise ValueError("Selecione o modo claro ou escuro.")
        with closing(self._conectar()) as conexao, conexao:
            conexao.execute("BEGIN IMMEDIATE")
            self._ler(conexao)
            conexao.execute("UPDATE Preferencias SET tema=? WHERE id=1", (tema,))
