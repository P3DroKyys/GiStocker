"""Registro de falhas técnicas e mensagens sem expor detalhes internos na tela."""
from datetime import datetime
import sqlite3
import traceback
import config


def registrar_falha(falha):
    try:
        with (config.DIRETORIO_BASE / 'erros.log').open('a', encoding='utf-8') as arquivo:
            arquivo.write(f'\n[{datetime.now().isoformat()}]\n')
            arquivo.write(''.join(traceback.format_exception(falha)))
    except OSError:
        # Um disco cheio não deve causar outra exceção ao tentar registrar a primeira.
        pass


def mensagem_falha(falha):
    if isinstance(falha, (sqlite3.Error, OSError)):
        registrar_falha(falha)
        return ('Não foi possível acessar ou gravar os dados. Verifique o espaço em disco '
                'e a permissão da pasta. Confira o estoque e o histórico antes de repetir a operação.')
    return str(falha)
